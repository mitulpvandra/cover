package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class NextComicTest {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\chromedriver.exe");		
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.monkeyuser.com");
        driver.findElement(By.xpath("//div[@class='thumb prev nobefore']")).click();
        driver.findElement(By.xpath("//div[@class='thumb prev nobefore']")).click();
        WebElement currentImage = driver.findElement(By.xpath("//div[@class='thumb prev nobefore']//img"));
        String oldValue = currentImage.getAttribute("title");
        driver.findElement(By.xpath("//div[@class='thumb next nobefore']")).click();
        Long started = System.nanoTime();
 		while(true) {

 			currentImage = driver.findElement(By.xpath("//div[@class='thumb next nobefore']//img"));
             String newValue = currentImage.getAttribute("title");

 			if(!oldValue.equals(newValue)) {

 				System.out.println("Next comic test worked correctly");
 				break; // Success

 			}
 			if(System.nanoTime() > started + 30*1000*1000000) {

 				System.out.println("Next comic test  failed");
 				break; // Failed

 			}
 			try {
 			Thread.sleep(1000);

 			} catch (InterruptedException e) {
 				e.printStackTrace();

 			}

 		}
 		driver.close();

	}

}
