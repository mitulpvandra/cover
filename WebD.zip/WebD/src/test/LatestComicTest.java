package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LatestComicTest {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\chromedriver.exe");		
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.monkeyuser.com");
        WebElement currentImage = driver.findElement(By.xpath("//div[@class='content']//img"));
        String oldValue = currentImage.getAttribute("src");
        driver.findElement(By.xpath("//img[@title='fresh out of the oven']")).click();
        Long started = System.nanoTime();
 		while(true) {

 			currentImage = driver.findElement(By.xpath("//div[@class='content']//img"));
             String newValue = currentImage.getAttribute("src");

 			if(oldValue.equals(newValue)) {

 				System.out.println("Latest comic test worked correctly");
 				break; // Success

 			}
 			if(System.nanoTime() > started + 30*1000*1000000) {

 				System.out.println("Latest comic test  failed");
 				break; // Failed

 			}
 			try {
 			Thread.sleep(1000);

 			} catch (InterruptedException e) {
 				e.printStackTrace();

 			}

 		}
 		driver.close();

	}

}
