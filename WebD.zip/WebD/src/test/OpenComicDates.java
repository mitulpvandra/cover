 package test;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenComicDates {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\chromedriver.exe");		
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.monkeyuser.com");
        driver.findElement(By.xpath("//*[@id='list']")).click();
       // Boolean firstImg = driver.findElements(By.cssSelector("[class='toc'] [class='toc-entry'] [class='et']")).getText().contains("December  4, 2018");
        
        List<WebElement> names = driver.findElements(By.className("et"));
      // int count = driver.findElements(By.className("et")).size();
        int count = names.size();
       System.out.println(count);
      // long count = driver.findElements(By.cssSelector("[class='toc'] [class='toc-entry'] [class='et']")).size();
       //System.out.println(count);
     //  String oldValue = "December 4, 2018";
       driver.findElements(By.className("toc-entry")).get(43).getText();
       
       //System.out.println(text);
       Thread.sleep(3000);
       driver.findElements(By.className("toc-entry")).get(43).click();
       Thread.sleep(3000);
       driver.findElement(By.xpath("//*[@id='list']")).click();
       driver.findElements(By.className("toc-entry")).get(64).click();
       Thread.sleep(3000);
       driver.findElement(By.xpath("//*[@id='list']")).click();
       driver.findElements(By.className("toc-entry")).get(113).click();
       Thread.sleep(3000);
//    for(int i=0;i<150;i++)
//        {
//        	String text1 = driver.findElements(By.className("toc-entry")).get(i).getText();
//        	System.out.println(i);
//        	System.out.println(text1);
////        	if(oldValue.equals(text)) {
////        	System.out.println(text);
////        	}
//        }
//        
//        while()
//        {
//        	
//        }
        //String imageText = firstImg.getAttribute("strong");
      //  System.out.println(firstImg);
      driver.close();

	}

}
